# 🔑 **Complete API Setup Guide**

## **What APIs You Need**

### **ABSOLUTELY REQUIRED** (for bot to work)

#### 1️⃣ **DISCORD_TOKEN** ⭐
**What it is:** Your Discord bot's authentication key

**How to get it:**
1. Go to `discord.com/developers/applications`
2. Click **"New Application"** → name it anything
3. Go to **"Bot"** tab → click **"Add Bot"**
4. Under TOKEN section, click **"Copy"**
5. Paste this in `.env` as `DISCORD_TOKEN`

**Format:** Long string like `MTE2NzA4Njk0ODI1MTI4MzUxMg.GvqZX1...`

---

#### 2️⃣ **DISCORD_CHANNEL_ID** ⭐
**What it is:** Which Discord channel gets bot trade alerts

**How to get it:**
1. In Discord, enable **Developer Mode**
   - Settings → Advanced → toggle Developer Mode
2. Right-click the channel you want bot to use
3. Click **"Copy Channel ID"**
4. Paste in `.env` as `DISCORD_CHANNEL_ID`

**Format:** Just numbers like `1234567890123456789`

---

### **HIGHLY RECOMMENDED** (for better performance)

#### 3️⃣ **HELIUS_API_KEY** 🚀
**What it is:** Fast Solana RPC for scanning coins

**Why you want it:**
- ✅ 2-3x faster coin scanning
- ✅ More reliable than public RPC
- ✅ Better uptime

**How to get it:**
1. Go to `helius.dev`
2. Click **"Get Started"** → Sign up (free tier)
3. Create API key in dashboard
4. Copy it
5. Paste in `.env` as `HELIUS_API_KEY`

**Is it required?** No, bot works without it (just slower)

---

#### 4️⃣ **JUPITER_API_KEY** 💱
**What it is:** Enables actual trading on Solana

**Why you need it:** Only if you want LIVE mode (real money trading)

**How to get it:**
1. Go to `jupiter.ag`
2. Look for **"API"** or **"Developers"** section
3. Sign up for API access (usually free)
4. Get your API key
5. Paste in `.env` as `JUPITER_API_KEY`

**Is it required?** 
- ❌ Not for PAPER mode
- ✅ Yes for LIVE mode

---

### **OPTIONAL** (not needed in .env)

#### 5️⃣ **PRIVATE_KEY** 🔐
**What it is:** Your Solana wallet private key (for spending real SOL)

**⚠️ IMPORTANT:** Do NOT put this in `.env` file!

**How to set it safely:**
1. Bot runs in PAPER mode first
2. Test it out (no real money at risk)
3. When ready for LIVE mode:
   - Use `/setprivatekey` command in Discord
   - Only server owner can run this
   - Key is set in memory only
   - Never touches `.env` or files

**How to get your private key:**
1. Open your Solana wallet (Phantom, etc)
2. Settings → Security → "Export Private Key"
3. Copy it (base58 format)
4. In Discord, run: `/setprivatekey [paste_key_here]`
5. Bot confirms and is ready for LIVE mode

**Security:**
- ✅ Never in files
- ✅ Only admin can set it
- ✅ Discord ephemeral reply (only you see it)
- ✅ Lost on bot restart (you set it again)

---

## **Setup Steps**

### **Step 1: Get Discord Token & Channel (5 min)**

```
1. discord.com/developers/applications
2. New Application
3. Add Bot
4. Copy TOKEN
5. Right-click channel → Copy Channel ID
6. Done!
```

### **Step 2: Get Helius API (2 min)**

```
1. helius.dev
2. Sign up free
3. Get API key
4. Copy it
5. Done!
```

### **Step 3: Create .env File**

```env
DISCORD_TOKEN=your_token_here
DISCORD_CHANNEL_ID=your_channel_id_here
HELIUS_API_KEY=your_helius_key_here
JUPITER_API_KEY=optional_for_now
PAPER_START_SOL=10
```

**Save and you're ready to deploy!**

---

### **Step 4: Deploy to Google Cloud**

See QUICKSTART.md for how to deploy.

---

### **Step 5: Set Private Key (Only for LIVE mode)**

Once bot is running on Google Cloud:

1. In Discord, type:
   ```
   /setprivatekey [your_base58_private_key]
   ```

2. Bot responds: ✅ **PRIVATE KEY SET!**

3. Now you can use `/start` → choose LIVE mode

---

## **Complete .env Example**

```env
# Required
DISCORD_TOKEN=MTE2NzA4Njk0ODI1MTI4MzUxMg.GvqZX1.-5Ug...
DISCORD_CHANNEL_ID=1234567890123456789

# Recommended
HELIUS_API_KEY=d7a9e8c5...

# Optional (get later if going live)
JUPITER_API_KEY=your_key_if_you_have_it

# Paper trading
PAPER_START_SOL=10

# RPC (optional, defaults to public)
RPC_URL=https://api.mainnet.solana.com
```

---

## **Minimum to Get Started**

To deploy bot RIGHT NOW and start trading in PAPER mode:

```env
DISCORD_TOKEN=your_token
DISCORD_CHANNEL_ID=your_channel_id
HELIUS_API_KEY=your_helius_key
PAPER_START_SOL=10
```

That's it. Everything else is optional.

---

## **To Add LIVE Mode Later**

When you want to trade with real money:

1. Get `JUPITER_API_KEY` from jupiter.ag
2. Bot is already running
3. Use `/setprivatekey` to add private key via Discord
4. Use `/start` → choose LIVE
5. Done!

---

## **Security Best Practices**

✅ **DO:**
- Store token in `.env` (it's rotatable)
- Use `/setprivatekey` for private key (not in files)
- Keep `.env` private (don't share/upload)
- Use different API keys for different bots

❌ **DON'T:**
- Put private key in `.env` or git
- Share DISCORD_TOKEN with anyone
- Commit `.env` to GitHub
- Use same key for multiple bots

---

## **Troubleshooting**

### "Bot doesn't respond to commands"
- Check DISCORD_TOKEN is correct
- Check bot has permissions in channel
- Check DISCORD_CHANNEL_ID is correct

### "Can't use LIVE mode"
- Did you run `/setprivatekey`?
- Are you the server owner?
- Is your private key valid?

### "Scanning is slow"
- Get HELIUS_API_KEY (makes it 2-3x faster)
- Or just let it run (public RPC works too)

### "Private key gets rejected"
- Make sure it's base58 format
- Not JSON array format (just the string)
- Try getting it fresh from your wallet

---

## **API Limits (Free Tier)**

| API | Free Tier | Enough? |
|-----|-----------|---------|
| Discord | Unlimited | ✅ YES |
| Helius | 1k req/sec | ✅ YES (bot uses ~10 req/sec) |
| Jupiter | Unlimited | ✅ YES |
| Solana RPC | Public | ✅ YES (slower but free) |

You won't hit any limits with this bot!

---

**That's it!** You're ready to set up APIs and deploy. 🚀
