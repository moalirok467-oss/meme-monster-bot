# ⚡ Quick Start Guide — 5 Minutes to Trading

## Step 1: Discord Bot Setup (2 min)

1. Go to https://discord.com/developers/applications
2. Click **"New Application"** → name it "Meme Monster"
3. Go to **Bot** tab → click **"Add Bot"**
4. Under **TOKEN**, click **"Copy"** → save this somewhere
5. Scroll down → enable **"Message Content Intent"**
6. Save changes

## Step 2: Get Bot in Your Server (1 min)

1. Go to **OAuth2** → **URL Generator**
2. Select scopes: `bot`
3. Select permissions:
   - ✅ Send Messages
   - ✅ Use Slash Commands
   - ✅ Read Messages/View Channels
4. Copy the generated URL
5. Paste in browser → authorize → done!

Bot now in your server! ✅

## Step 3: Setup Local Files (1 min)

1. **Download all files** from outputs folder
2. Create a folder called `meme-monster`
3. Copy these files into it:
   - `trading-bot.js`
   - `package.json`
   - `.env.example` (rename to `.env`)
   - `README.md`

## Step 4: Configure .env (1 min)

Open `.env` in a text editor:

```env
DISCORD_TOKEN=paste_token_from_step_1_here
DISCORD_CHANNEL_ID=paste_your_channel_id_here
HELIUS_API_KEY=get_from_helius.dev_if_you_want
PAPER_START_SOL=10
```

**How to get DISCORD_CHANNEL_ID:**
- Right-click your Discord channel
- "Copy Channel ID" (if you don't see this, enable Developer Mode in Discord settings)

## Step 5: Install & Run (1 min)

Open terminal in your `meme-monster` folder:

```bash
npm install
npm start
```

You'll see:
```
✅ Logged in as Meme-Monster#1234
```

Bot is now **LIVE**! 🚀

## Step 6: Start Trading

In Discord:

```
/start
```

Bot asks: **Paper or Live?**
- 🟡 **Paper** = Virtual 10 SOL, no risk
- 🔴 **Live** = Real money (only if you added PRIVATE_KEY)

**For first time: Choose PAPER!** 📝

## That's It! 🎉

Now the bot will:
- ✅ Scan for meme coins every 30 seconds
- ✅ Buy good ones automatically
- ✅ Take profits at 25%, 50%, 90%
- ✅ Protect with trailing stops
- ✅ Post updates in Discord

## Useful Commands

```
/status       → See bot performance
/balance      → Check your balance
/positions    → See open trades
/pause        → Stop new trades
/resume       → Start trading again
/risky        → Hunt 100x coins!
/help         → All commands
```

## Want Live Trading? (Optional)

Only if you're comfortable with real money:

1. Get your Solana private key (base58 format)
2. Add to `.env`:
   ```
   PRIVATE_KEY=your_base58_private_key_here
   ```
3. Get Jupiter API key from jupiter.ag
4. Add to `.env`:
   ```
   JUPITER_API_KEY=your_key_here
   ```
5. Restart bot with `npm start`
6. Use `/start` → choose **Live**

⚠️ **Start with tiny positions!** Test with 0.01 SOL first.

## Troubleshooting

### Bot won't start
```bash
npm install    # Make sure dependencies are installed
npm start      # Try again
```

### Bot in Discord but no commands
- Discord Developer Portal → Bot → Message Content Intent **enabled?**
- Try **@MemeMonster /help** in chat
- Discord might need cache clear (restart Discord)

### "DISCORD_TOKEN missing"
- Check `.env` file
- `DISCORD_TOKEN=` is there?
- Token is correct (not with extra spaces)?

### "Permission denied" errors
- Bot needs these permissions in your channel:
  - Send Messages
  - Use Slash Commands
  - Read Messages

## Pro Tips

💡 **Paper Mode First**: Let it run 24h in paper mode before going live. Check `/status` to see win rate.

💡 **Small Positions**: First live trades should be 0.01-0.05 SOL. Scale up after you see results.

💡 **Risky Mode**: Try `/risky` for higher upside. More risk too! Paper test first.

💡 **Keep SOL Reserved**: Leave at least 0.05 SOL in wallet for gas fees.

💡 **Monitor Daily**: Check `/status` and `/positions` daily. Don't just set & forget.

## What's Different in v3.0?

✨ **Interactive Setup** — `/start` command to choose paper/live
✨ **Risky Mode** — Hunt 100x coins with `/risky`
✨ **Full Personality** — Emojis, bold text, engaging messages
✨ **Smart Filters** — Actually finds buyable coins (not dry)
✨ **Persistent Balance** — Paper balance survives restarts
✨ **Better Stats** — Win rate, P/L tracking, detailed status

## Next Steps

1. ✅ Bot is running in paper mode
2. 📊 Check `/status` after 10 minutes
3. 💰 Let it run for 24h+
4. 📈 Review `/positions` to see it working
5. 🚀 When ready, try live with tiny positions

## Questions?

Check `README.md` for detailed documentation on:
- How the bot works
- Each command explained
- Configuration options
- Performance metrics
- Risk management

---

**You're all set!** Go make some gains! 🤖💪

*Type `/help` in Discord to see all commands anytime.*
