# 🚀 Google Cloud Setup - EZ Mode

## **Step 1: Get Your Discord Channel ID (2 min)**

- Right-click your Discord channel
- Click "Copy Channel ID"
- Open `.env` file → replace `YOUR_CHANNEL_ID_HERE` with it
- Save `.env`

---

## **Step 2: Create GitHub Repo (3 min)**

- Go to `github.com` → sign up if needed
- Click "New repository"
- Name: `meme-monster-bot`
- Click "Create repository"

---

## **Step 3: Upload Files to GitHub (2 min)**

- In GitHub repo, click "Add file" → "Upload files"
- Select these files from your computer:
  - `trading-bot.js`
  - `package.json`
  - `.env`
  - `Dockerfile` (create it, see below)
  - `.dockerignore` (optional)
- Click "Commit changes"

**How to create Dockerfile:**
- Create a text file called `Dockerfile` (no extension)
- Copy this inside:
```
FROM node:20
WORKDIR /app
COPY package.json .
RUN npm install
COPY trading-bot.js .
CMD ["node", "trading-bot.js"]
```
- Save it
- Upload to GitHub

---

## **Step 4: Create Google Cloud Account (2 min)**

- Go to `cloud.google.com`
- Click "Get started free"
- Sign in with Google
- Add payment method (won't charge)
- Click "CREATE PROJECT"

---

## **Step 5: Enable Cloud Run (1 min)**

- Search "Cloud Run" at top
- Click "Cloud Run"
- Click blue "ENABLE" button
- Wait for it to load

---

## **Step 6: Deploy from GitHub (3 min)**

- Click blue "CREATE SERVICE"
- Click "Deploy from source code"
- Click "SET UP WITH CLOUD BUILD"
- Choose "GitHub"
- Click "CONNECT"
- Select `meme-monster-bot` repo
- Click "SAVE"
- Fill form:
  - Service name: `meme-monster-bot`
  - Region: `us-central1`
  - Click "DEPLOY"

**⏳ Wait 5-10 min while it builds...**

---

## **Step 7: Add Environment Variables (2 min)**

- Click your service `meme-monster-bot`
- Click "EDIT & DEPLOY NEW REVISION"
- Scroll to "Runtime settings"
- Click "RUNTIME ENVIRONMENT VARIABLES"
- Add these (copy from your `.env`):
  - `DISCORD_TOKEN` = your token
  - `DISCORD_CHANNEL_ID` = your channel ID
  - `HELIUS_API_KEY` = your helius key
  - `JUPITER_API_KEY` = your jupiter key
- Click "DEPLOY"

**⏳ Wait 2-3 min...**

---

## **Step 8: Check Logs (1 min)**

- In Cloud Run, click your service
- Go to "LOGS" tab
- Look for: `✅ Logged in as YourBotName#...`
- If you see it = **BOT IS LIVE!** 🎉

---

## **Step 9: Test in Discord (1 min)**

- Go to your Discord channel
- Type: `/start`
- Bot should respond with buttons!
- Click `🟡 Paper` to start

**Done!** Bot is running 24/7! 🚀

---

## **That's It!**

Total time: ~20-25 minutes

Bot is now:
- ✅ Running on Google Cloud (24/7)
- ✅ Connected to Discord
- ✅ Ready to trade in PAPER mode
- ✅ Will auto-restart if it crashes

**Enjoy!** 🤖💪
