# 🤖 Meme Coin Monster Bot v3.0

**The ultimate Discord trading bot for Solana meme coins.** Now with **interactive modes**, **paper & live trading**, **risky mode**, and **real personality**! 🚀

## ✨ What's New in v3.0

### 🎯 Interactive /start Command
- **Dynamic mode selection** right in Discord
- Choose between **Paper Trading** (risk-free) and **Live Trading** (real money)
- Remembers your choice and balance across restarts
- Shows your current balance immediately

### 💥 Risky Mode
- Hunt **100x+ potential** coins instead of stable picks
- Adjusts filters for newer, riskier pairs
- Works in **both paper and live modes**
- Toggle with `/risky` command
- More aggressive but higher upside

### 📊 Paper & Live Modes
- **Paper Trading**: Practice with virtual 10 SOL, see how you'd do
- **Live Trading**: Real money with real gains (and losses!)
- Seamlessly switch between modes with `/start`
- Paper balance persists across restarts
- Separate position tracking

### 😎 Full Personality
- **Emojis & bold text** everywhere
- Engaging, conversational responses (not robotic!)
- Real-time trade notifications with P/L
- Cool trade profiles: "ELITE 🔥", "STRONG 💪", "RISKY HOT 🌪️"
- Win rate tracking and stats

### 🔧 Smart Filters
- **Not a dry reset** — actually finds buyable coins
- Risky mode includes coins down to $3k market cap
- Fresh pair detection (< 15 min old)
- Real buyer analysis prevents rug pulls
- Liquidity-to-MC ratio checks

## 📋 Commands

| Command | Description | Example |
|---------|-------------|---------|
| `/start` | 🚀 Choose paper or live mode | Pick your adventure! |
| `/risky` | 💥 Toggle risky coin hunting | Hunt 100x gems |
| `/status` | 📊 Full bot stats & P/L | See everything |
| `/balance` | 💰 Show your balance | How much you got |
| `/positions` | 📋 Open positions & gains | Track your trades |
| `/scan` | 🔎 Force scan immediately | Find coins now |
| `/pause` | ⏸️ Stop new entries | Protect from FOMO |
| `/resume` | ▶️ Resume trading | Get back in action |
| `/help` | ❓ Command list | This screen |

## 🚀 How It Works

### Entry Strategy
1. **Scans every 30 seconds** for new meme coin pairs
2. **Filters by lane:**
   - **NORMAL lane**: Established coins (5min+ old, $25k+ MC)
   - **FRESH lane**: New coins (< 15min old, $8k+ MC) with strict safety checks
   - **RISKY lane**: High-risk coins (< 30min old, $3k+ MC) — when you toggle `/risky`
3. **Safety checks:**
   - Rug.report score validation
   - Holder concentration analysis
   - Real buyer detection
4. **Intelligent position sizing** based on coin quality score (0-100)

### Exit Strategy
1. **Partial take-profit at:**
   - +25% gain
   - +50% gain
   - +90%+ gain
2. **Trailing stop** that tightens as profit grows
3. **Time exit** if held too long with no movement
4. **Quality-based profiles** determine how long to hold

### Position Profiles

**Normal Lane:**
- **ELITE 🔥** (92+): 30% position, hold 12h, aggressive partials
- **STRONG 💪** (85+): 24% position, hold 10h, balanced exit
- **GOOD ✨** (77+): 18% position, hold 8h, steady profits
- **SPECULATIVE 🎲** (0+): 8% position, hold 4h, quick scalps

**Fresh Lane:**
- **FRESH-A 🚀** (92+): 10% position, hold 3h, fast scaling
- **FRESH-B ⭐** (84+): 8% position, hold 2.5h
- **FRESH-C 🌟** (76+): 5% position, hold 2h
- **FRESH-SPEC 🎯** (0+): 3% position, hold 1.5h

**Risky Lane:**
- **RISKY ELITE 🌪️** (88+): 20% position, aggressive exits at 20%/60%/150%
- **RISKY HOT 🔥** (80+): 15% position, fast money mode
- **RISKY SPEC 💥** (0+): 10% position, 100x or bust (kinda)

## 🔧 Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Create `.env` File
Copy `.env.example` to `.env` and fill in:

```env
# Get from Discord Developer Portal
DISCORD_TOKEN=MTE...

# Your bot's channel
DISCORD_CHANNEL_ID=1234567890

# Helius or Quicknode RPC
HELIUS_API_KEY=your_key

# For live trading only (base58 private key)
PRIVATE_KEY=

# Starting paper balance
PAPER_START_SOL=10
```

### 3. Discord Bot Setup
1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Create new application
3. Go to "Bot" → "Add Bot"
4. Copy token → paste in `.env` as `DISCORD_TOKEN`
5. Enable "Message Content Intent"
6. Go to OAuth2 → URL Generator
7. Scopes: `bot`
8. Permissions: `Send Messages`, `Use Slash Commands`, `Read Messages`
9. Copy generated URL → open in browser → invite bot

### 4. Run the Bot
```bash
npm start
```

## 💰 Paper vs Live Mode

### Paper Trading (Default)
```
✅ Start with 10 SOL
✅ No real money at risk
✅ Perfect for testing
✅ Trades are simulated (1% fees)
✅ Good for learning the bot
```

### Live Trading
```
⚠️  Real SOL from your wallet
⚠️  Real profits AND losses
⚠️  Need private key in .env
⚠️  Requires Jupiter API key
⚠️  Use small amounts first!
```

**Switch anytime with `/start`** — your paper balance is always saved!

## 💥 Risky Mode

### What It Does
- Hunts **newly launched coins** (freshest possible)
- Includes tiny market cap coins ($3k-$5M)
- Lower liquidity requirements (just $5k)
- Less strict holder concentration checks
- Aims for **100x+** moves (rare but possible!)

### When to Use
- Testing small amounts in **paper mode first**
- You know the risks and can handle volatility
- Want moonshot potential, not steady gains
- Have separate bankroll for high-risk trades

### Toggle It
```
/risky    ← Turns it on/off
/status   ← Shows current mode
```

## 📊 State & Persistence

All data saved in `monster-state.json`:
- ✅ Paper balance & realized P/L
- ✅ Open positions (entry price, qty, etc)
- ✅ Trade history (for stats)
- ✅ Current mode (paper/live/risky)
- ✅ Bot stats (scans, buys, sells, win rate)

**Survives restarts** — pick up right where you left off!

## ⚙️ Configuration

### Scan Settings
```js
SCAN_INTERVAL_MS=30000          // Scan every 30 seconds
MAX_CANDIDATES_PER_SCAN=10      // Check top 10 coins per scan
```

### Position Sizing
```js
MIN_POSITION_SOL=0.01           // Minimum entry size
MAX_POSITIONS=5                 // Max open trades at once
RESERVE_SOL=0.02                // Always keep this in wallet
```

### Safety
```js
MAX_LIVE_TRADE_SLIPPAGE_BPS=500 // 5% slippage max
COOLDOWN_MS=90000               // Prevent rapid re-entries
```

## 🎯 Strategy Tips

### Paper Trading
1. Start with `/start` → select **Paper**
2. Let it run 24h+ to see performance
3. Check `/status` for win rate
4. Adjust your risk tolerance
5. Switch to live when confident

### Live Trading
1. Start **SMALL** (0.1 SOL positions)
2. Watch for 2-3 days
3. Increase size once comfortable
4. Keep `RESERVE_SOL` high until you trust it
5. Use `/pause` if you need to step back

### Risky Mode
1. **Enable in paper first**
2. Run for a week, track results
3. If you like it, enable in live with **tiny positions**
4. Expect 50% failure rate but 5-10x on winners
5. Use only money you can afford to lose

## 🐛 Troubleshooting

### Bot shows "❌ LIVE mode enabled but no PRIVATE_KEY"
- You set `LIVE_TRADING=true` but no private key
- Either add PRIVATE_KEY or restart in paper mode
- Use `/start` to choose paper mode

### Positions not closing
- Check if `/pause` is active
- Review filter settings (might be too strict)
- Manually close with webhook if needed

### Not finding coins
- Filters might be too strict
- Try enabling `/risky` mode
- Check if RPC/Helius is working
- Verify API keys in .env

### Discord not responding
- Check `DISCORD_TOKEN` is correct
- Verify bot has permissions in channel
- Bot might need "Send Messages" permission

## 📈 Performance Metrics

The bot tracks:
- **Scans**: Number of scanning runs
- **Candidates**: Coins that passed initial filters
- **Buys**: Actual entry trades
- **Sells**: Exit trades
- **Wins**: Profitable closes
- **Win Rate**: Wins / Total Sells
- **Realized P/L**: Total profit/loss in SOL

Check with `/status` anytime!

## ⚠️ Important Notes

1. **Past performance ≠ future results** — crypto is volatile
2. **Use paper mode first** — it's literally free practice
3. **Private keys are secret** — never share your `.env` file
4. **Rug pulls happen** — bot has safety but can't prevent all
5. **Start small in live** — test with 0.1 SOL positions first
6. **Monitor regularly** — don't just set it and forget
7. **Understand the risks** — only trade what you can lose

## 🤝 Support & Issues

If something breaks:
1. Check `.env` configuration
2. Restart the bot (`CTRL+C` then `npm start`)
3. Check Discord channel for error messages
4. Review `monster-state.json` for data integrity

## 🚀 Version History

**v3.0** — Interactive modes, paper/live switch, risky mode, personality
**v2.0** — Multi-lane filtering, partial take-profits, trailing stops
**v1.0** — Basic Solana meme coin trading bot

---

**Made with ❤️ for degen traders. Go make that bread! 🍞**

*Remember: Trade smart, not hard. Start small, scale slow. 🤖*
